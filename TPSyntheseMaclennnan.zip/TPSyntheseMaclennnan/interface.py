import tkinter as tk
from tkinter import ttk, Text
import serial
import moduleTP5 as tp
from datetime import datetime
import time
import gestionnaireBD as bd


s = serial.Serial("COM7")
password = "1234"


class Interface(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Interface graphique - TP5 - Pico")
        self.geometry("350x150")


class FenetrePrincipal(ttk.Frame):

    def __init__(self, conteneur):
        super().__init__(conteneur)
        options = {'padx': 2, 'pady': 2}

        # etiquette
        self.lbl_titre = ttk.Label(self, text="SYSTÈME D'ALARME")
        self.lbl_titre.pack(**options)

        # bouton1
        self.btn_demarrer = ttk.Button(
            self, text="Activer le système d'alarme")
        self.btn_demarrer["command"] = self.demarrerAlarme
        self.btn_demarrer.pack(**options)

        # bouton2
        self.btn_arret = ttk.Button(
            self, text="Désactiver le système d'alarme")
        self.btn_arret["state"] = "disabled"
        self.btn_arret["command"] = self.arretAlarme
        self.btn_arret.pack(**options)
        self.pack(**options)

        # bouton3
        self.btn_prendre_mesure = ttk.Button(
            self, text="Valider code d'accès")
        self.btn_prendre_mesure["state"] = "disabled"
        self.btn_prendre_mesure["command"] = self.validerAlarme
        self.btn_prendre_mesure.pack(**options)

        # champ de saisie
        self.ety_utilisateur = Text(self, width=50, height=5)
        self.ety_utilisateur["state"] = "disabled"
        self.ety_utilisateur.pack(**options)

        # etiquette
        self.lbl_etat = ttk.Label(self, text="Désactivé", foreground="red")
        self.lbl_etat.pack(**options)

        # boite de liste
        self.lst_mesure = tk.Listbox(self, width=67, height=20)
        self.lst_mesure.pack(**options)
        

    def demarrerAlarme(self):
        s.write(b"ON\n")
        self.lbl_etat.config(text="Active", foreground="green")
        self.btn_prendre_mesure["state"] = "active"
        self.btn_arret["state"] = "active"
        self.ety_utilisateur["state"] = "normal"
        now = datetime.now()
        date = now.strftime("%I:%M:%S")
        data = s.readline()
        data = str(data)[2:-5]
        data2 = s.readline()
        data2 = str(data2)[2:-5]
        activation = "ACTIVER"
        validation = ""
        mesure = tp.Evenement(
            date, activation, validation, data, data2)
        self.lst_mesure.insert(tk.END, mesure)
        bd.ajouterMesure(date, activation, validation, data, data2)
        bd.connexion.commit()

    def arretAlarme(self):
        s.write(b"OFF\n")
        self.lbl_etat.config(text="Désactivé", foreground="red")
        self.btn_prendre_mesure["state"] = "disabled"
        self.ety_utilisateur["state"] = "disabled"
        now = datetime.now()
        date = now.strftime("%I:%M:%S")
        data = s.readline()
        data = str(data)[2:-5]
        data2 = s.readline()
        data2 = str(data2)[2:-5]
        activation = "DESACTIVER"
        validation = ""
        mesure = tp.Evenement(
            date, activation, validation, data, data2)
        self.lst_mesure.insert(tk.END, mesure)
        bd.ajouterMesure(date, activation, validation, data, data2)
        bd.connexion.commit()


    def validerAlarme(self):
        self.ety_utilisateur_texte = self.ety_utilisateur.get("1.0", "end-1c")
        if self.ety_utilisateur_texte == password:
            s.write(b"SYS_VALIDE\n")
            now = datetime.now()
            date = now.strftime("%I:%M:%S")
            data = s.readline()
            data = str(data)[2:-5]
            data2 = s.readline()
            data2 = str(data2)[2:-5]
            activation = ""
            validation = "ACCES AUTORISER"
            mesure = tp.Evenement(
                date, activation, validation, data, data2)
            self.lst_mesure.insert(tk.END, mesure)
            bd.ajouterMesure(date, activation, validation, data, data2)
            bd.connexion.commit()

        else:
            s.write(b"SYS_INVALIDE\n")
            now = datetime.now()
            date = now.strftime("%I:%M:%S")
            data = s.readline()
            data = str(data)[2:-5]
            data2 = s.readline()
            data2 = str(data2)[2:-5]
            activation = ""
            validation = "ACCES REFUSER"
            mesure = tp.Evenement(
                date, activation, validation, data, data2)
            self.lst_mesure.insert(tk.END, mesure)
            bd.ajouterMesure(date, activation, validation, data, data2)
            bd.connexion.commit()



if __name__ == "__main__":
    app = Interface()
    fenetre = FenetrePrincipal(app)
    app.mainloop()
