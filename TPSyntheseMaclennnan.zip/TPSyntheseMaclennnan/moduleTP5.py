import datetime

class Evenement:
    def __init__(self, dateHeureEvenement, activation,validation,valeurEvenement, valeurEvenement2):
        self.dateHeureEvenement = dateHeureEvenement
        self.activation = activation
        self.validation = validation
        self.valeurEvenement = valeurEvenement
        self.valeurEvenement2 = valeurEvenement2
        
    def __repr__(self):
        return self.dateHeureEvenement + " " + self.activation + " " + self.validation + " " + self.valeurEvenement + " " + self.valeurEvenement2
    
    def afficherEvenement(self):
        return self.dateHeureEvenement + " " + self.activation + " " + self.validation + " " + self.valeurEvenement + " " + self.valeurEvenement2
