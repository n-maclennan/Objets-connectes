import sys
from machine import Pin, PWM, I2C, ADC
from time import sleep
from I2C_LCD import I2CLcd
import _thread
import dht11

# lumiere
adc = ADC(26)

# buzzer declaration
buzzer = PWM(Pin(18))

# déclaration du module i2c
i2c = I2C(0, sda=Pin(0), scl=Pin(1), freq=400000)

# adresse de connexion i2c
i2c_add = i2c.scan()[0]

# objet lcd
lcd = I2CLcd(i2c, i2c_add, 2, 16)

# leds
led_vert = Pin(17, Pin.OUT)
led_rouge = Pin(16, Pin.OUT)

# capteur humidite
dht = dht11.DHT11(15)

terminateThread = False
rep = ""
temperature = 0
humidite = 0
mesure = ""
lumiere = 0


def lireRep():
    global terminateThread, rep
    while True:
        if terminateThread:
            break
        rep = sys.stdin.readline().strip()


def led_on():
    lcd.clear()
    led_rouge.value(0)
    led_vert.value(1)
    sleep(0.5)
    led_vert.value(0)
    sleep(0.5)
    led_vert.value(1)
    sleep(0.5)
    led_vert.value(0)
    sleep(0.5)
    led_vert.value(1)
    sleep(0.5)
    led_vert.value(0)
    led_vert.value(1)


def buzzlightyear():
    buzzer.freq(300)
    buzzer.duty_u16(1000)
    sleep(1)
    buzzer.duty_u16(0)
    sleep(1)


def led_off():
    led_vert.value(0)
    led_rouge.value(1)
    sleep(0.5)
    led_rouge.value(0)
    sleep(0.5)
    led_rouge.value(1)
    sleep(0.5)
    led_rouge.value(0)
    sleep(0.5)
    led_rouge.value(1)
    sleep(0.5)
    led_rouge.value(0)


def valide():
    lcd.clear()
    sleep(1)
    lcd.putstr("Merci! Code valide")
    sleep(1)
    lcd.clear()
    sleep(1)


def invalide():
    lcd.clear()
    sleep(1)
    lcd.putstr("Desole! Code invalide")
    sleep(1)
    lcd.clear()
    sleep(1)


def luminosite():
    while True:
        if adc.read_u16 == 0:
            print("Error")
        else:
            lum = adc.read_u16()
            sleep(0.1)
            return lum


def sys_allumer():
    lcd.clear()
    lcd.putstr("Systeme d'alarme activiter")
    sleep(2)
    lcd.clear()
    sleep(2)
    lcd.putstr("Entrez le code")
    sleep(2)
    lcd.clear()


def sys_eteint():
    lcd.clear()
    sleep(2)
    lcd.putstr("Systeme d'alarme desactiver")
    sleep(2)
    lcd.clear()


def temperature_ambiente():
    if dht.measure() == 0:
        print("Erreur")
    else:
        sleep(2)
        temperature = dht.temperature()
        humidite = dht.humidity()
        temp = "{:.2f}C".format(temperature)
        hum = "{:.2f}%".format(humidite)
        lcd.putstr("temp: " + temp)
        lcd.move_to(0, 1)
        lcd.putstr("humidite: " + hum)
        mesure = ("temp: "+temp + " humidite: " + hum)
        sleep(2)
        return mesure


_thread.start_new_thread(lireRep, ())
mesure = ""

try:
    while True:
        if rep.lower() == "on":
            led_on()
            buzzlightyear()
            sys_allumer()
            temperature = temperature_ambiente()
            lumiere = luminosite()
            print(temperature)
            print(lumiere)

        elif rep.lower() == "sys_valide":
            led_on()
            valide()
            lcd.clear()
            print(temperature)
            print(lumiere)
            rep = "on"

        elif rep.lower() == "sys_invalide":
            led_off()
           
            
            lcd.clear()
            print(temperature)
            print(lumiere)
            rep = "off"

        elif rep.lower() == "off":
            rep = ""
            led_off()
            buzzlightyear()
            lcd.clear()
            sys_eteint()
            print(temperature)
            print(lumiere)
            

except KeyboardInterrupt:
    terminateThread = True
