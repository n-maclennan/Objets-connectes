import sqlite3

connexion = ""
nomBD = "mesure.db"
table_mesure = "MESURE"
cle_no = ""
cle_date = "DATE"
cle_activation = ""
cle_validation = ""
cle_data = ""
cle_data2 = ""

# connexion de la db


def connexionBD():
    global connexion
    try:
        # connexion dans la db
        connexion = sqlite3.connect(nomBD)
        print("Ouverture de la base de données")
    except sqlite3.Error as error:
        print("Erreur de connexion à la base de données", error)

# fermeture de la db


def fermetureDB():
    if connexion:
        # fermeture de la db
        connexion.close()
        print("Fermeture de la base de données")
    else:
        print("Erreur de connexion à la base de données")

# verifier si la table existe deja


def verifierExisteTable(table):
    existe = False
    # creation d'un curseur
    cur = connexion.cursor()

    sql_tableExiste = "SELECT count(name)"\
                      "FROM sqlite_master"\
                      "WHERE type='table AND name ='" + table + "'"

    try:
        # exécution du selection exsitence de la table sur le curseur
        cur.execute(sql_tableExiste)

        # verification si count=1 > table existe
        if cur.fetchone()[0] == 1:
            existe = True
        else:
            existe = False
    except sqlite3.Error as error:
        print("Erreur lors verifier existe la table sur a base de données", error)
    return existe


def creationTable():
    tableMesure = "CREATE TABLE " + table_mesure + " ( "\
        + cle_no + "INTEGER PRIMARY KEY AUTOINCREMENT, "\
        + cle_date + "TEXT, "\
        + cle_activation+"TEXT"\
        + cle_validation+"TEXT"\
        + cle_data+"REAL NOT NULL"\
        + cle_data2+"REAL NOT NULL;"
    connexionBD()

    if verifierExisteTable(table_mesure):
        print("La table existe déjà")
    else:
        try:
            # création de la table distance
            connexion.execute(tableMesure)
            print("Création de la table")
        except sqlite3.Error as error:
            print("Erreur lors de creation de table sur la base de données", error)

    # fermetureDB()

# ajouter une mesure dans la table de la DB


def ajouterMesure(dateMesure, activation, validation, tempMesure, lumMesure):
    # sql_insert = "INSERT INTO " + table_mesure + " ("+ cle_date+", "+ cle_activation+", "+", "+ cle_validation+ ", "+", "+ cle_data+"VALUES (?, ?),"+ cle_data2+") VALUES (?);"
    sql_insert = "INSERT INTO MESURE VALUES (?,?,?,?,?,?)"
    connexionBD()

    try:
        cur_insert = connexion.cursor()
        donnees_param = (5,dateMesure, activation,
                         validation, tempMesure, lumMesure)
        cur_insert.execute(sql_insert, donnees_param)
        # sauvegarde des données
        connexion.commit()
        print("Enregistrement ajouté dans la table")
        # cur_insert.close()
    except sqlite3.Error as error:
        print("Erreur lors d'un ajout sur la base de données", error)
    finally:
        # fermetureDB()
        pass

        # supprimer une mesure dans la table de la db selon un no


def supprimerMesure(noMesure):
    sql_supp = "DELETE FROM " + table_mesure +\
               "WHERE" + cle_no + "= %s " % noMesure

    connexionBD()
    try:
        cur_supp = connexion.cursor()
        cur_supp.execute(sql_supp)
        # sauvegarder donnees
        connexion.commit()
        print("Enregistrement supprimes de la table")
        # cur_supp.close()
    except sqlite3.Error as error:
        print("Erreur lors de suppression sur la base de données", error)
    finally:
        # fermetureDB()
        pass

# selection des mesures dans la table db


def selectionListeMesure():
    sql_select = "SELECT " + cle_no + ", " + cle_date + ", " + cle_activation + ", " + cle_validation + ", "+cle_data + cle_data2 + \
                 " FROM " + table_mesure

    connexionBD()
    try:
        cur_select = connexion.cursor()
        cur_select.execute(sql_select)
        data = cur_select.fetchall()

    except sqlite3.Error as error:
        print("Erreur lors d'une selection sur la base de données", error)
    finally:
        # fermetureDB()
        pass
    return data
