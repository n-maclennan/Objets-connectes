import unittest
import moduleTP5 as tp


class TestEvenement(unittest.TestCase):

    def setUp(self):
        self.dateHeureEvenement = "2021-10-01 12:00:00"
        self.activation = True
        self.validation = False
        self.valeurEvenement = 10
        self.valeurEvenement2 = "test"

    def test_init(self):
        evenement = tp.Evenement(self.dateHeureEvenement, self.activation,
                              self.validation, self.valeurEvenement, self.valeurEvenement2)
        self.assertEqual(evenement.dateHeureEvenement, self.dateHeureEvenement)
        self.assertEqual(evenement.activation, self.activation)
        self.assertEqual(evenement.validation, self.validation)
        self.assertEqual(evenement.valeurEvenement, self.valeurEvenement)
        self.assertEqual(evenement.valeurEvenement2, self.valeurEvenement2)
        
    def setUp(self):
        self.event = tp.Evenement("2021-10-01 12:00:00", "activated",
                               "validated", "value1", "value2")

    def test_repr(self):
        expected_output = "2021-10-01 12:00:00 activated validated value1 value2"
        self.assertEqual(repr(self.event), expected_output)



if __name__ == '__main__':
    unittest.main()
